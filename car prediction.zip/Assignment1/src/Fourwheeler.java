import java.util.Scanner;

public class Fourwheeler extends Fuel {
	public static void display() {
		System.out.println("THIS IS FOUR WHEELER PROVIDE INFO FOR SPECIFIC IDENTIFICATION");
		mileage();
	}
	public static void  mileage() {
		Scanner scan5=new Scanner(System.in);
		System.out.println("enter mileage:");
		int mileage=scan5.nextInt();
		if(mileage>45 && mileage<=50) {
			System.out.println("SUGGESTION:MARUTHI (OR) HONDA");
		}
		else if(mileage>35 && mileage<=45) {
			System.out.println("SUGGESTION:SWIFT");
		}
		else if(mileage>=25&& mileage<=35) {
			System.out.println("SUGGESTION:RANGEROVER || LANDROVER");
		}
		else {
			System.out.println("invalid mileage for four wheelers!!");
		}
		
}
}
