import java.util.Scanner;

public class Fuel extends Vehicle {
public static void Fuel (int wheels) {
	//	int Fuel;
	//System.out.println(wheels);
	if(wheels==2) {
		java.util.Scanner scan1 =new Scanner(System.in);
		System.out.println("(type)Fuel->1-no,2-petrol,3-disel");
		System.out.println("enter fuel type :");
		
		String Fuel =scan1.nextLine();
		if(Fuel.contentEquals("no")){
			System.out.println("its bicycle");
		}
		else {
		System.out.println("its twowheeler");
			Twowheeler two=new Twowheeler();
			two.display();
		}
	}
	else if(wheels==3) {
		java.util.Scanner scan3 =new Scanner(System.in);
		System.out.println("(type)Fuel->1-no,2-petrol,3-disel");
		System.out.println("enter fuel type :");
		String Fuel =scan3.nextLine();
		if(Fuel.contentEquals("no")){
			System.out.println("SUGGESSTION:RISHAWALA");
		}
		else{
			Threewheeler three=new Threewheeler();
			three.display();
		}
	}
	else if(wheels==4) {
		java.util.Scanner scan4 =new Scanner(System.in);
		System.out.println("(type)Fuel->1-no,2-petrol,3-disel");
		System.out.println("enter fuel type :");
		String Fuel =scan4.nextLine();
		if(Fuel.contentEquals("no")){
			System.out.println("SUGGESSTION:ELECTRIC CAR");
		}
		else{
			Fourwheeler four=new Fourwheeler();
			four.display();
		}
	}
	else if((wheels==5)||(wheels==7)) {
		System.out.println("invalid!!");
	}
	else if(wheels==6) {
		Sixwheeler six=new Sixwheeler();
		six.display();
	}
	else if(wheels==8) {
		Eightwheeler eight=new Eightwheeler();
		eight.display();
	}
	else {
		System.out.println("invalid!!");
	}
}
}
