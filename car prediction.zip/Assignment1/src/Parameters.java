
public class Parameters {
	public static void main(String[] args) {
		System.out.println("\\VEHICLE CLASSIFICATION\\");
		Vehicle a=new Vehicle();
		a.Wheels();
	}
}
