
public class Sixwheeler extends Fuel {
	public static void display() {
		System.out.println("SUGGESTION: TRUCK!");
}
}
