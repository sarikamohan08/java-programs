public class Threewheeler extends Vehicle {
	public static void display() {
		System.out.println("SUGGESTION: AUTO!");
		
}
}

