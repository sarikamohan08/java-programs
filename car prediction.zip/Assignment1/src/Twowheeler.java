import java.util.Scanner;

public class Twowheeler extends Fuel {
		public static void display() {
			System.out.println("THIS IS TWO WHEELER! PROVIDE INFO FOR SPECIFIC IDENTIFICATION");
			mileage();
		}
	public static void  mileage() {
		Scanner scan2 =new Scanner(System.in);
		System.out.println("enter mileage:");
		int mileage=scan2.nextInt();
		
		if(mileage>50 && mileage<=z) {
			System.out.println("SUGGESTION:Duo\\n\"");
		}
		else if(mileage>35 && mileage<=45) {
			System.out.println("SUGGESTION:ACTIVA\n");
		}
		else if(mileage>45 && mileage<=60) {
			System.out.println("SUGGESTION:HONDA SPLENDOR\\n");
		}
		else if(mileage>=25&& mileage<=35) {
			System.out.println("SUGGESTION:Rx100,Royal Enfield\n");
		}
		
	}
}
