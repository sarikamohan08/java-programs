import java.util.Scanner;
public class Vehicle {
	public static  void  Wheels(){
		Scanner scan =new Scanner(System.in);
		System.out.println("enter number of wheels:");
        int wheels =scan.nextInt();
        System.out.println(wheels);
		Fuel fuel=new Fuel();
		fuel.Fuel(wheels);
		}
	}

