import java.util.Scanner;

public class Aiml extends Mscpgm{
	public static void aimlcourse() {
		System.out.println("AIML-COURSES:\n"
				+ "1.Advanced data structures\n"
				+ "2.Theory of programming language\n"
				+ "3.Programming and paradigm\n");
		Scanner scan2=new Scanner (System.in);
		System.out.println("enter your choice(Aiml):");
		String aimlch=scan2.nextLine();
		System.out.println(aimlch);
		Aimlfaculty f =new Aimlfaculty();
		f.aimlfaculty(aimlch);
		
	}
}
