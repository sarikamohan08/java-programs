import java.util.Scanner;

public class Aimlfaculty extends Aiml {
	public static void aimlfaculty(String aimlch) {
		if(aimlch.contentEquals("Advanced data structures")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.B.Arunkumar\n"
					+ "2.Dr.S.Geetha\n"
					+ "3.Dr.H.parthi");
			Scanner scan3=new Scanner (System.in);
			System.out.println("enter your choice(Aiml):");
			String aimlfac=scan3.nextLine();
			Register r=new Register();
			r.register(aimlfac,aimlch);
			//System.out.println(aimlfac);
		}
			else if(aimlch.contentEquals("Theory of programming language")) {
				System.out.println("faculty available:\n"
						+ "1.Dr.P.G.sapna\n"
						+ "2.Dr.M.k.Babu\n"
						+ "3.Dr.M.kailasam");
				Scanner scan4=new Scanner (System.in);
				System.out.println("enter your choice(Aiml):");
				String aimlfac=scan4.nextLine();
				Register r=new Register();
				r.register(aimlfac,aimlch);
				//System.out.println(aimlfac);
		}
			else if(aimlch.contentEquals("Programming and paradigm")) {
				System.out.println("faculty available:\n"
						+ "1.Dr.T.Gunasekaran\n"
						+ "2.Dr.R.Santhidevi\n"
						+ "3.Dr.M.kavya");
				Scanner scan5=new Scanner (System.in);
				System.out.println("enter your choice(Aiml):");
				String aimlfac=scan5.nextLine();
				Register r=new Register();
				r.register(aimlfac,aimlch);
			//	System.out.println(aimlfac);
	}
			else {
				System.out.println("invalid input for the course!!");
			}
}
}
