import java.util.Scanner;

public class CivilBEcourse extends Civilpgm {
	public static void civilcoursebe() {
		System.out.println("Available course:\n"
				+ "1.Structural Analysis\n"
				+ "2.Ground Water Hydrology\n"
				+ "3.Surveying\n");
		Scanner Sc=new Scanner(System.in);
		System.out.println("enter subjects:");
		String sub=Sc.nextLine();
		System.out.println(sub); 
		CivilBEfaculty f =new CivilBEfaculty ();
		f.civilbefaculty (sub);
	}
}
