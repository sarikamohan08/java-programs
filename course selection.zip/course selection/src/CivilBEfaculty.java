import java.util.Scanner;

public class CivilBEfaculty extends CivilBEcourse{
	public static void civilbefaculty(String sub) {
		if(sub.contentEquals("Structural Analysis")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.G.Rega\n"
					+ "2.Dr.S.Sandhosh\n"
					+ "3.Dr.D.Giri prasath\n");
			Scanner sca=new Scanner (System.in);
			System.out.println("enter your choice:");
			String civilbefac=sca.nextLine();
			Register r=new Register();
			r.register(civilbefac,sub);
		}
		else if(sub.contentEquals("Ground Water Hydrology")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.K.Sasikumar\n"
					+ "2.Dr.B.Abhishek\n"
					+ "3.Dr.V.Niranjan\n");
			Scanner a=new Scanner (System.in);
			System.out.println("enter your choice:");
			String civilbefac=a.nextLine();
			Register r=new Register();
			r.register(civilbefac,sub);
		}
		else if(sub.contentEquals("Surveying")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.V.kishore\n"
					+ "2.Dr.H.Mithra\n"
					+ "3.Dr.S.Naren\n");
			Scanner a=new Scanner (System.in);
			System.out.println("enter your choice:");
			String civilbefac=a.nextLine();
			Register r=new Register();
			r.register(civilbefac,sub);
		}
		else {
			System.out.println("invalid course");
		}
}
}
