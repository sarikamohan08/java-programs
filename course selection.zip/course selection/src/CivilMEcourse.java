import java.util.Scanner;

public class CivilMEcourse extends Civilpgm{
	public static void civilcourseme() {
		System.out.println("Available course:\n"
				+ "1.Construction cost Dynamics\n"
				+ "2.Low-cost housing\n"
				+ "3.Contracts and Valuation\n");
		Scanner b=new Scanner(System.in);
		System.out.println("enter subjects:");
		String sub=b.nextLine();
		System.out.println(sub); 
		CivilMEfaculty f =new CivilMEfaculty ();
		f.civilmefaculty (sub);
	}
}
