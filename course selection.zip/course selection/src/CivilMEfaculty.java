import java.util.Scanner;

public class CivilMEfaculty  extends CivilMEcourse{
	public static void civilmefaculty(String sub) {
		if(sub.contentEquals("Construction cost Dynamics")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.F.Mohammed\n"
					+ "2.Dr.P.sneha\n"
					+ "3.Dr.D.prasath\n");
			Scanner c=new Scanner (System.in);
			System.out.println("enter your choice(Aiml):");
			String civilmefac=c.nextLine();
			Register r=new Register();
			r.register(civilmefac,sub);
		}
		else if(sub.contentEquals("Low-cost housing")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.M.Sangeetha\n"
					+ "2.Dr.P.Shanmugarajan\n"
					+ "3.Dr.B.pranesh\n");
			Scanner d=new Scanner (System.in);
			System.out.println("enter your choice(Aiml):");
			String civilmefac=d.nextLine();
			Register r=new Register();
			r.register(civilmefac,sub);
		}
		else if(sub.contentEquals("Contracts and Valuation")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.J.Manoj\n"
					+ "2.Dr.E.Binny\n"
					+ "3.Dr.R.Nirmal\n");
			Scanner e=new Scanner (System.in);
			System.out.println("enter your choice(Aiml):");
			String civilmefac=e.nextLine();
			Register r=new Register();
			r.register(civilmefac,sub);
		}
		else {
			System.out.println("invalid course");
		}
}
}
