import java.util.Scanner;

public class Civilpgm {
	public static void civil() {
		System.out.println("SUB-PROGRAMME:1.BE\n"
				+ "2.ME\n");
		Scanner s=new Scanner(System.in);
		System.out.println("enter the sub-programme:");
		String civilpgm=s.nextLine();
		if(civilpgm.contentEquals("BE")) {
			CivilBEcourse civilbe=new CivilBEcourse();
			civilbe.civilcoursebe();
		}
		if(civilpgm.contentEquals("ME")) {
			CivilMEcourse civilme=new CivilMEcourse();
			civilme.civilcourseme();
		}
		
}
}
