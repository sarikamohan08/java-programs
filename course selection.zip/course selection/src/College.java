import java.util.Scanner;

public class College {

	public static void main(String[] args) {
		System.out.println("COIMBATORE INSTITUE OF TECHNOLOGY");
		Dept d=new Dept();
		d.dept();
	}

}
