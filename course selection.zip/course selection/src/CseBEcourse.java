import java.util.Scanner;

public class CseBEcourse extends Csepgm {
	public static void csecoursebe() {
		System.out.println("Available course:\n"
				+ "1.Discrete Structures\n"
				+ "2.Operating Systems\n"
				+ "3.Computer Networks\n");
		Scanner e=new Scanner(System.in);
		System.out.println("enter subjects:");
		String sub=e.nextLine();
		System.out.println(sub); 
		CseBEfaculty f =new CseBEfaculty ();
		f.csebefaculty (sub);
	}
	}

