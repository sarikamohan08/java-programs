import java.util.Scanner;

public class CseBEfaculty extends CseBEcourse {
	public static void csebefaculty(String sub) {
		if(sub.contentEquals("Discrete Structures")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.V.Amritha\n"
					+ "2.Dr.S.Priya\n"
					+ "3.Dr.E.parithie\n");
			Scanner f=new Scanner (System.in);
			System.out.println("enter your choice:");
			String csebefac=f.nextLine();
			Register r=new Register();
			r.register(csebefac,sub);
		}
		else if(sub.contentEquals("Operating Systems")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.G.Varshini\n"
					+ "2.Dr.A.sidarth\n"
					+ "3.Dr.B.Divya\n");
			Scanner g=new Scanner (System.in);
			System.out.println("enter your choice:");
			String csebefac=g.nextLine();
			Register r=new Register();
			r.register(csebefac,sub);
		}
		else if(sub.contentEquals("Computer Networks")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.S.shivani\n"
					+ "2.Dr.T.sruthi\n"
					+ "3.Dr.B.shyam\n");
			Scanner h=new Scanner (System.in);
			System.out.println("enter your choice:");
			String csebefac=h.nextLine();
			Register r=new Register();
			r.register(csebefac,sub);
		}
		else {
			System.out.println("invalid course");
		}
}
}

