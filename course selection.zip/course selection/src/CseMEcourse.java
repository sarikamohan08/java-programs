import java.util.Scanner;

public class CseMEcourse extends Csepgm {
	public static void csecourseme() {
		System.out.println("Available course:\n"
				+ "1.Cloud Computing\n"
				+ "2.Advances in DIP\n"
				+ "3.Advances in OS\n");
		Scanner i=new Scanner(System.in);
		System.out.println("enter subjects:");
		String sub=i.nextLine();
		System.out.println(sub); 
		CseMEfaculty f =new CseMEfaculty ();
		f.csemefaculty (sub);
	}
}
