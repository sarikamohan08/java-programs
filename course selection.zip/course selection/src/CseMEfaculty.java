import java.util.Scanner;

public class CseMEfaculty extends CseMEcourse {
	public static void csemefaculty(String sub) {
		if(sub.contentEquals("Cloud Computing")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.V.Srinithi\n"
					+ "2.Dr.S.Niruvaish\n"
					+ "3.Dr.E.Sakthi\n");
			Scanner j=new Scanner (System.in);
			System.out.println("enter your choice:");
			String csemefac=j.nextLine();
			Register r=new Register();
			r.register(csemefac,sub);
		}
		else if(sub.contentEquals("Advances in DIP")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.L.Elango\n"
					+ "2.Dr.V.Moorthi\n"
					+ "3.Dr.R.Navin\n");
			Scanner k=new Scanner (System.in);
			System.out.println("enter your choice:");
			String csemefac=k.nextLine();
			Register r=new Register();
			r.register(csemefac,sub);
		}
		else if(sub.contentEquals("Advances in OS")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.N.Antony\n"
					+ "2.Dr.F.Zakkir\n"
					+ "3.Dr.G.Dekshi\n");
			Scanner l=new Scanner (System.in);
			System.out.println("enter your choice:");
			String csemefac=l.nextLine();
			Register r=new Register();
			r.register(csemefac,sub);
		}
		else {
			System.out.println("invalid course");
		}
}
}
