import java.util.Scanner;

public class Csepgm {
	public static void cse() {
		System.out.println("SUB-PROGRAMME:1.BE\n"
				+ "2.ME\n");
		Scanner d=new Scanner(System.in);
		System.out.println("enter the sub-programme:");
		String csepgm=d.nextLine();
		if(csepgm.contentEquals("BE")) {
			CseBEcourse csebe=new CseBEcourse();
			csebe.csecoursebe();
		}
		else if(csepgm.contentEquals("ME")) {
			CseMEcourse cseme=new CseMEcourse();
			cseme.csecourseme();
		}
}
}
