import java.util.Scanner;

public class Dcs extends Mscpgm {
	public static void dcscourse() {
		System.out.println("DCS courses:\n"
				+ "1.Statistics\n"
				+ "2.Python programming\n"
				+ "3.Data structures\n");
		Scanner scan13=new Scanner (System.in);
		System.out.println("enter your choice(Aiml):");
		String dcsch=scan13.nextLine();
		System.out.println(dcsch);
		Dcsfaculty f =new Dcsfaculty();
		f.dcsfaculty(dcsch);
}
}
