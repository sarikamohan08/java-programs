import java.util.Scanner;

public class Dcsfaculty extends Dcs{
	public static void dcsfaculty(String dcsch) {
		if(dcsch.contentEquals("Statistics")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.V.Hariharn\n"
					+ "2.Dr.S.Sumithra\n"
					+ "3.Dr.T.Ehzil\n");
			Scanner scan14=new Scanner (System.in);
			System.out.println("enter your choice(ss):");
			String dcsfac=scan14.nextLine();
			Register r=new Register();
			r.register(dcsfac,dcsch);
		}
		else if(dcsch.contentEquals("Python programming")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.V.Vani\n"
					+ "2.Dr.S.Ntin\n"
					+ "3.Dr.E.Mugil\n");
			Scanner scan15=new Scanner (System.in);
			System.out.println("enter your choice(ss):");
			String dcsfac=scan15.nextLine();
			Register r=new Register();
			r.register(dcsfac,dcsch);
		}
		else if(dcsch.contentEquals("Data structures")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.S.Purnaa shree\n"
					+ "2.Dr.S.Kabinesh\n"
					+ "3.Dr.M.Mohanraj\n");
			Scanner scan16=new Scanner (System.in);
			System.out.println("enter your choice(ss):");
			String dcsfac=scan16.nextLine();
			Register r=new Register();
			r.register(dcsfac,dcsch);
		}
}
}
