import java.util.Scanner;

public class Dept {
	public static void dept() {
		System.out.println("choose your course department:\n"
				+ "1.Msc\n"
				+ "2.Mech\n"
				+ "3.Civil\n"
				+ "4.Cse\n");
		Scanner scan=new Scanner (System.in);
		System.out.println("enter your choice(department:");
		String deptch=scan.nextLine();
		System.out.println(deptch);
		if(deptch.contentEquals("Msc")) {
			Mscpgm m=new Mscpgm();
			m.msc();
		}
		else if(deptch.contentEquals("Mech")) {
			Mechpgm m=new Mechpgm();
			m.mech();
		}
		else if(deptch.contentEquals("Civil")) {
			Civilpgm m=new Civilpgm();
			m.civil();
		}
		else if(deptch.contentEquals("Cse")) {
			Csepgm m=new Csepgm();
			m.cse();
		}
	}
}
