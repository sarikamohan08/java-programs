import java.util.Scanner;

public class Ds extends Mscpgm {
	public static void dscourse() {
		System.out.println("DS courses:\n"
				+ "1.Probability\n"
				+ "2.R programming\n"
				+ "3.Linear algebra\n");
		Scanner scan9=new Scanner (System.in);
		System.out.println("enter your choice(Aiml):");
		String dsch=scan9.nextLine();
		System.out.println(dsch);
		Dsfaculty f =new Dsfaculty();
		f.dsfaculty(dsch);
		
	}
}
