import java.util.Scanner;

public class Dsfaculty extends  Ds{
	public static void dsfaculty(String dsch) {
		if(dsch.contentEquals("Probability")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.B.Harish\n"
					+ "2.Dr.S.Akash\n"
					+ "3.Dr.T.sriram\n");
			Scanner scan10=new Scanner (System.in);
			System.out.println("enter your choice(ss):");
			String dsfac=scan10.nextLine();
			Register r=new Register();
			r.register(dsfac,dsch);
		}
		else if(dsch.contentEquals("R programming")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.H.Amarnath\n"
					+ "2.Dr.S.Danny\n"
					+ "3.Dr.T.Srinath\n");
			Scanner scan11=new Scanner (System.in);
			System.out.println("enter your choice(ss):");
			String dsfac=scan11.nextLine();
			Register r=new Register();
			r.register(dsfac,dsch);
		}
		else if(dsch.contentEquals("Linear algebra")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.M.Sathya bama\n"
					+ "2.Dr.R.Muthukumar\n"
					+ "3.Dr.C.Ramya\n");
			Scanner scan12=new Scanner (System.in);
			System.out.println("enter your choice(ss):");
			String dsfac=scan12.nextLine();
			Register r=new Register();
			r.register(dsfac,dsch);
		}
		else {
			System.out.println("invalid input for the course!!");
		}
	}
}
