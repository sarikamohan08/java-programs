import java.util.Scanner;

public class MechBEcourse extends Mechpgm{
	public static void mechcoursebe() {
		System.out.println("Availabel courses:\n"
				+ "1.Automobile engineering\n"
				+ "2.Heat and mass transfer\n"
				+ "3.Design of machine elements\n");
		Scanner Scan12=new Scanner(System.in);
		System.out.println("enter subjects:");
		String sub=Scan12.nextLine();
		System.out.println(sub); 
		MechBEfaculty f =new MechBEfaculty ();
		f.mechbefaculty (sub);
		
	}
}
