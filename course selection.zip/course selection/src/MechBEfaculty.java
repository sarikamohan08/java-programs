import java.util.Scanner;

public class MechBEfaculty extends MechBEcourse{
	public static void mechbefaculty(String sub) {
		if(sub.contentEquals("Automobile engineering")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.C.Sukith\n"
					+ "2.Dr.G.pragedsh\n"
					+ "3.Dr.D.salman");
			Scanner scan13=new Scanner (System.in);
			System.out.println("enter your choice(Aiml):");
			String mechbefac=scan13.nextLine();
			Register r=new Register();
			r.register(mechbefac,sub);
		}
		else if(sub.contentEquals("Heat and mass transfer")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.R.Sudhrshan\n"
					+ "2.Dr.L.Abijith\n"
					+ "3.Dr.G.Asmitha");
			Scanner scan14=new Scanner (System.in);
			System.out.println("enter your choice(Aiml):");
			String mechbefac=scan14.nextLine();
			Register r=new Register();
			r.register(mechbefac,sub);
		}
		else if(sub.contentEquals("Design of machine elements")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.S.Sundar raj\n"
					+ "2.Dr.E.pavithra\n"
					+ "3.Dr.D.karthikeyan");
			Scanner scan14=new Scanner (System.in);
			System.out.println("enter your choice(Aiml):");
			String mechbefac=scan14.nextLine();
			Register r=new Register();
			r.register(mechbefac,sub);
		}
		else {
			System.out.println("invalid course");
		}
}
}
