import java.util.Scanner;

public class MechMEcourse extends Mechpgm {
	public static void mechcourseme() {
		System.out.println("Available courses:\n"
				+ "1.Manufacturing science and technology\n" + 
				"2.Design of transmission systems\n" + 
				"3.Advanced Fluid Machines\n");
		Scanner Scan15=new Scanner(System.in);
		System.out.println("enter subjects:");
		String sub=Scan15.nextLine();
		System.out.println(sub); 
		MechMEfaculty f =new MechMEfaculty ();
		f.mechmefaculty (sub);
		
	}

}
