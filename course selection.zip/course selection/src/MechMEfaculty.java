import java.util.Scanner;

public class MechMEfaculty extends MechMEcourse {
	public static void mechmefaculty(String sub) {
		if(sub.contentEquals("Manufacturing science and technology")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.S.Srijith\n"
					+ "2.Dr.R.Shrihari\n"
					+ "3.Dr.P.krish");
			Scanner scan16=new Scanner (System.in);
			System.out.println("enter your choice(Aiml):");
			String mechmefac=scan16.nextLine();
			Register r=new Register();
			r.register(mechmefac,sub);
		}
		else if(sub.contentEquals("Design of transmission systems")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.B.jayakumar\n"
					+ "2.Dr.U.Imran\n"
					+ "3.Dr.K.Katheswarn");
			Scanner scan17=new Scanner (System.in);
			System.out.println("enter your choice(Aiml):");
			String mechmefac=scan17.nextLine();
			Register r=new Register();
			r.register(mechmefac,sub);
		}
		else if(sub.contentEquals("Advanced Fluid Machines")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.P.Arun prakash\n"
					+ "2.Dr.D.Bharath\n"
					+ "3.Dr.I.Izzar");
			Scanner scan18=new Scanner (System.in);
			System.out.println("enter your choice(Aiml):");
			String mechmefac=scan18.nextLine();
			Register r=new Register();
			r.register(mechmefac,sub);
		}
		else {
			System.out.println("invalid course");
		}
}
}
