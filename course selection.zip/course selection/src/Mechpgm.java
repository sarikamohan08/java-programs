import java.util.Scanner;

public class Mechpgm {
	public static void mech() {
		System.out.println("SUB-PROGRAMME:1.BE\n"
				+ "2.ME\n");
		Scanner scan17=new Scanner(System.in);
		System.out.println("enter the sub-programme:");
		String mechpgm=scan17.nextLine();
		if(mechpgm.contentEquals("BE")) {
			MechBEcourse mechbe=new MechBEcourse();
			mechbe.mechcoursebe();
		}
		if(mechpgm.contentEquals("ME")) {
			MechMEcourse mechme=new MechMEcourse();
			mechme.mechcourseme();
		}
}
}
