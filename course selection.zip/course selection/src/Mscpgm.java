import java.util.Scanner;

public class Mscpgm {
	public static  void msc() {
		System .out.println("choose your course programme\n"
				+ "1.AIML\n"
				+ "2.SS\n"
				+ "3.DS\n"
				+ "4.DCS\n");
		Scanner scan1=new Scanner (System.in);
		System.out.println("enter your choice(programme):");
		String pgmch=scan1.nextLine();
		System.out.println(pgmch);
		if(pgmch.contentEquals("AIML")) {
			Aiml a=new Aiml();
			a.aimlcourse();
	}
		else if(pgmch.contentEquals("SS")) {
			Ss s=new Ss();
			s.sscourse();
	}
		else if(pgmch.contentEquals("DS")) {
			Ds d=new Ds();
			d.dscourse();
	}
		else if(pgmch.contentEquals("DCS")) {
			Dcs dc=new Dcs();
			dc.dcscourse();
	}
		else {
			System.out.println("invalid input!!");
		}
}
}
