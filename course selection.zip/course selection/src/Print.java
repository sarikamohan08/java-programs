
public class Print {
	public static void printdetails(String name,String email,String phone,String degree,int year,float cgpa,int yearcomp,String course,String fac) {
		System.out.println("Name:"+name);
		System.out.println("email-id:"+email);
		System.out.println("phone number:"+phone);
		System.out.println("currently studying degree:"+degree);
		System.out.println("year of study:"+year);
		System.out.println("cgpa:"+cgpa);
		System.out.println("enter year of year completion:"+yearcomp);
		System.out.println("Course you have choosen:"+course);
		System.out.println("Assigned faculty for course you have choosen:"+fac);
		System.out.println("Successfully registered!!\n"
				+ "THANK YOU !! ");
	}
}
