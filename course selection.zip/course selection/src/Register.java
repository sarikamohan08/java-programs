import java.util.Scanner;

public class Register  {

	public static void register(String fac,String course) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter name:");
		String name=scan.nextLine();
		Scanner scan1=new Scanner(System.in);
		System.out.println("enter email-id:");
		String email=scan1.nextLine();
		Scanner scan2=new Scanner(System.in);
		System.out.println("enter current CGPA:");
		float cgpa=scan2.nextFloat();
		Scanner scan3=new Scanner(System.in);
		System.out.println("enter phone number:");
		String phone=scan3.nextLine();
		Scanner scan6=new Scanner(System.in);
		System.out.println("enter currently studying degree :");
		String degree=scan6.nextLine();
		Scanner scan4=new Scanner(System.in);
		System.out.println("enter year of study:");
		int year=scan4.nextInt();
		Scanner scan5=new Scanner(System.in);
		System.out.println("enter year of year completion:");
		int yearcomp=scan5.nextInt();
		
	Print p =new Print();
	p.printdetails(name,email,phone,degree,year,cgpa,yearcomp,course,fac);
	//public void static print()
		
	}
}
