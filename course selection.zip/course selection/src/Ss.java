import java.util.Scanner;

public class Ss extends Mscpgm {
	public static void sscourse() {
		System.out.println("SS courses:\n"
				+ "1.Digital electronics\n"
				+ "2.C programming\n"
				+ "3.Calculus\n");
		Scanner scan6=new Scanner (System.in);
		System.out.println("enter your choice(Aiml):");
		String ssch=scan6.nextLine();
		System.out.println(ssch);
		Ssfaculty f =new Ssfaculty();
		f.ssfaculty(ssch);
		
	}
}
