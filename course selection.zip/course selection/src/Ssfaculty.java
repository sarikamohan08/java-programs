import java.util.Scanner;

public class Ssfaculty extends Ss{
	public static void ssfaculty(String ssch ) {
		if(ssch.contentEquals("Digital electronics")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.K.Abhinya\n"
					+ "2.Dr.S.Pavithra shri\n"
					+ "3.Dr.V.Sneha bharathi\n");
			Scanner scan7=new Scanner (System.in);
			System.out.println("enter your choice(ss):");
			String ssfac=scan7.nextLine();
			Register r=new Register();
			r.register(ssfac,ssch);
		}
		else if(ssch.contentEquals("C programming")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.M.Sanjaypranav\n"
					+ "2.Dr.K.Devasena\n"
					+ "3.Dr.J.Lekha sree\n");
			Scanner scan8=new Scanner (System.in);
			System.out.println("enter your choice(ss):");
			String ssfac=scan8.nextLine();
			Register r=new Register();
			r.register(ssfac,ssch);
		}
		else if(ssch.contentEquals("Calculus")) {
			System.out.println("faculty available:\n"
					+ "1.Dr.K.P.Nithish Kumaar\n"
					+ "2.Dr.M.Aatheeswarn\n"
					+ "3.Dr.S.Nandha kishore\n");
			Scanner scan9=new Scanner (System.in);
			System.out.println("enter your choice(ss):");
			String ssfac=scan9.nextLine();
			Register r=new Register();
			r.register(ssfac,ssch);
		}
		else {
			System.out.println("invalid input for the course!!");
		}
	}
}
